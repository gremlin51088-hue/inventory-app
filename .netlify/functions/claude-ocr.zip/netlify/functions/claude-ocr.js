// netlify/functions/claude-ocr.js
var https = require("https");
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};
var PROMPT = '\u05D0\u05EA\u05D4 \u05DE\u05E7\u05D1\u05DC \u05EA\u05DE\u05D5\u05E0\u05D4 \u05D0\u05D5 PDF \u05E9\u05DC \u05EA\u05E2\u05D5\u05D3\u05EA \u05DE\u05E9\u05DC\u05D5\u05D7 \u05D0\u05D5 \u05D4\u05E6\u05E2\u05EA \u05DE\u05D7\u05D9\u05E8 \u05D1\u05E2\u05D1\u05E8\u05D9\u05EA.\n\u05D4\u05D7\u05D6\u05E8 JSON \u05D1\u05DC\u05D1\u05D3, \u05DC\u05DC\u05D0 \u05E9\u05D5\u05DD \u05D8\u05E7\u05E1\u05D8 \u05DC\u05E4\u05E0\u05D9 \u05D0\u05D5 \u05D0\u05D7\u05E8\u05D9, \u05D1\u05E4\u05D5\u05E8\u05DE\u05D8 \u05D4\u05D6\u05D4:\n\n[{"\u05DE\u05E7\u05D8": "\u05E7\u05D5\u05D3 \u05D4\u05DE\u05D5\u05E6\u05E8", "\u05EA\u05D9\u05D0\u05D5\u05E8": "\u05D4\u05D8\u05E7\u05E1\u05D8 \u05E9\u05E0\u05DE\u05E6\u05D0 \u05D1\u05D9\u05DF \u05D4\u05DE\u05E7\u05D8 \u05DC\u05DB\u05DE\u05D5\u05EA", "\u05DB\u05DE\u05D5\u05EA": \u05DE\u05E1\u05E4\u05E8}]\n\n\u05D7\u05DC\u05E5 \u05E8\u05E7 \u05E9\u05D5\u05E8\u05D5\u05EA \u05DE\u05D8\u05D1\u05DC\u05EA \u05D4\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD \u2014 \u05E9\u05DC\u05D5\u05E9\u05D4 \u05E9\u05D3\u05D5\u05EA \u05DC\u05DB\u05DC \u05E9\u05D5\u05E8\u05D4:\n1. \u05DE\u05E7"\u05D8 \u2014 \u05E7\u05D5\u05D3 \u05D0\u05DC\u05E4\u05D0\u05E0\u05D5\u05DE\u05E8\u05D9 \u05DB\u05DE\u05D5 pls-lh200-f, trb38w12 (\u05DC\u05D0 \u05DE\u05E1\u05E4\u05E8 \u05E9\u05D5\u05E8\u05D4 \u05D5\u05DC\u05D0 \u05DE\u05E1\u05E4\u05E8 \u05EA\u05E2\u05D5\u05D3\u05D4)\n2. \u05EA\u05D9\u05D0\u05D5\u05E8 \u2014 \u05D4\u05D8\u05E7\u05E1\u05D8 \u05D4\u05D7\u05D5\u05E4\u05E9\u05D9 \u05E9\u05DE\u05D5\u05E4\u05D9\u05E2 \u05D1\u05D9\u05DF \u05E2\u05DE\u05D5\u05D3\u05EA \u05D4\u05DE\u05E7"\u05D8 \u05DC\u05E2\u05DE\u05D5\u05D3\u05EA \u05D4\u05DB\u05DE\u05D5\u05EA\n3. \u05DB\u05DE\u05D5\u05EA \u2014 \u05DE\u05E1\u05E4\u05E8 \u05E9\u05DC\u05DD \u05D1\u05DC\u05D1\u05D3 (\u05DC\u05DC\u05D0 \u05D9\u05D7\u05D9\u05D3\u05D5\u05EA, \u05DC\u05DC\u05D0 \u05DE\u05D7\u05D9\u05E8)\n\u05D4\u05EA\u05E2\u05DC\u05DD \u05DE\u05DB\u05D5\u05EA\u05E8\u05EA \u05D4\u05EA\u05E2\u05D5\u05D3\u05D4, \u05E9\u05DD \u05D4\u05E1\u05E4\u05E7, \u05DB\u05EA\u05D5\u05D1\u05EA, \u05DE\u05D7\u05D9\u05E8\u05D9\u05DD, \u05E1\u05D9\u05DB\u05D5\u05DE\u05D9\u05DD \u05D5\u05DE\u05E2"\u05DE.';
function httpsPost(options, body) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk;
      });
      res.on("end", () => resolve({ status: res.statusCode, body: data }));
    });
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, headers: CORS, body: JSON.stringify({ error: "ANTHROPIC_API_KEY \u05DC\u05D0 \u05DE\u05D5\u05D2\u05D3\u05E8 \u05D1-Netlify Environment Variables" }) };
  }
  let pages;
  try {
    const parsed = JSON.parse(event.body || "{}");
    pages = parsed.pages;
  } catch (e) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "JSON \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: " + e.message }) };
  }
  if (!pages || pages.length === 0) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "\u05DC\u05D0 \u05D4\u05EA\u05E7\u05D1\u05DC\u05D5 \u05EA\u05DE\u05D5\u05E0\u05D5\u05EA" }) };
  }
  try {
    const content = [];
    for (const base64 of pages) {
      content.push({
        type: "image",
        source: { type: "base64", media_type: "image/jpeg", data: base64 }
      });
    }
    content.push({ type: "text", text: PROMPT });
    const bodyStr = JSON.stringify({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 4096,
      messages: [{ role: "user", content }]
    });
    const result = await httpsPost({
      hostname: "api.anthropic.com",
      path: "/v1/messages",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "Content-Length": Buffer.byteLength(bodyStr)
      }
    }, bodyStr);
    if (result.status !== 200) {
      return { statusCode: 500, headers: CORS, body: JSON.stringify({ error: `Claude API ${result.status}: ${result.body}` }) };
    }
    const data = JSON.parse(result.body);
    const text = (data.content?.[0]?.text || "").trim();
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if (!jsonMatch) {
      return { statusCode: 200, headers: CORS, body: JSON.stringify({ items: [], raw: text }) };
    }
    const items = JSON.parse(jsonMatch[0]);
    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify({ items })
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ error: "\u05E9\u05D2\u05D9\u05D0\u05D4 \u05E4\u05E0\u05D9\u05DE\u05D9\u05EA: " + e.message })
    };
  }
};
